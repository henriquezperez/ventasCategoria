
package domain;


public class Compra {
    
    private int idCompra;
    private int idProveedor;
    private String nComprobante;
    private String fecha;
    private double total;
    private double descuento;
    private double iva;
    private  double totalPago;

    public int getIdCompra() {
        return idCompra;
    }

    public void setIdCompra(int idCompra) {
        this.idCompra = idCompra;
    }

    public int getIdProveedor() {
        return idProveedor;
    }

    public void setIdProveedor(int idProveedor) {
        this.idProveedor = idProveedor;
    }

    public String getnComprobante() {
        return nComprobante;
    }

    public void setnComprobante(String nComprobante) {
        this.nComprobante = nComprobante;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public double getTotalPago() {
        return totalPago;
    }

    public void setTotalPago(double totalPago) {
        this.totalPago = totalPago;
    }
    
    @Override
   public String toString(){
       
       return "idProducto: " + idCompra + " | idProveedor: " + idProveedor + "| nComprobante: " + nComprobante + "| Fecha: " + fecha + "| total: $" + total + "| descuento: $" + descuento + "| IVA: $"+ iva + " TotalPago: $" +totalPago;
    }
}
