package Interface;

import Test.ActionCRUD;
import Test.ClienteCRUD;
import Test.MarcaCRUD;
import java.util.Scanner;
import Test.PresentacionCRUD;
import Test.ProductoCRUD;
import Test.ProveedorCRUD;

public class MenuTabla {
      
    public static void CategoriaTB(){
        
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA CATEGORIA ***\n");
             Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    ActionCRUD.InsertData();
                    break;
                case 2:
                    ExDB();
                    ActionCRUD.ExtraerData();
                    break;
                case 3:
                    ActionCRUD.UpdateData();
                    break;
                case 4:
                   ActionCRUD.DeleteData();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla <<<");
    }
    
    public static void ClienteTB(){
      
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA CLIENTE ***\n");
           Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    ClienteCRUD.InsertData();
                    break;
                case 2:
                    ExDB();
                    ClienteCRUD.ExtraerData();
                    break;
                case 3:
                    ClienteCRUD.UpdateData();
                    break;
                case 4:
                   ClienteCRUD.DeleteData();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla<<<");
    }
    
    public static void MarcaTB(){
       
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA MARCA ***\n");
            Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    MarcaCRUD.InsertData();
                    break;
                case 2:
                    ExDB();
                    MarcaCRUD.ExtraerData();
                    break;
                case 3:
                    MarcaCRUD.UpdateData();
                    break;
                case 4:
                   MarcaCRUD.DeleteData();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla<<<");
    }
    
     public static void PresentacioTB(){
    
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA PRESENTACION ***\n");
            Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    PresentacionCRUD.InsertData();
                    break;
                case 2:
                    ExDB();
                    PresentacionCRUD.ExtraerData();
                    break;
                case 3:
                    PresentacionCRUD.UpdateData();
                    break;
                case 4:
                   PresentacionCRUD.DeleteData();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla<<<");
    }
     
      public static void ProductoTB(){
        
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA PRODUCTO ***\n");
            Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                   //TestProducto.Insert();
                    ProductoCRUD.InsertData();
                    break;
                case 2:                  
                    //TestProducto.SelectAll();
                    ExDB();
                    ProductoCRUD.ExtraerData();
                    break;
                case 3:
                    //TestProducto.Update();
                    ProductoCRUD.UpdateData();
                    break;
                case 4:
                    ProductoCRUD.DeleteData();
                   //TestProducto.Delete();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla<<<");
    }
      
       public static void ProveedorTB(){
       
        int op = 0;
        do{
            System.out.println("\t*** MENU TABLA PROVEEDOR ***\n");
            Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >5){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >5);
            switch(op){
                case 1:
                    ProveedorCRUD.InsertData();
                    break;
                case 2:
                    ExDB();
                    ProveedorCRUD.ExtraerData();
                    break;
                case 3:
                    ProveedorCRUD.UpdateData();
                    break;
                case 4:
                   ProveedorCRUD.DeleteData();
                    break;
            }
        }while(op != 5);
        System.out.println(">>> Salio de la tabla<<<");
    }
    
    public static void ProductDAOmenu() {
        
  
    }
       
    public static void Infor(){
       System.out.println("\nPROGRAMACÓN APLICADA 1");
       System.out.println("\nINTEGRANTES:"); 
       System.out.println("Marlon Enrique Moran Guevara");
       System.out.println("Jairo Vladimir Osorio Portillo");
       System.out.println("Wilmer Omar Alvarez Sanchez");
       System.out.println("Welner Edgardo Catalan Rivera");
       System.out.println("Kevin Miguel Henriquez Perez\n");
    }
    
    public static void Menu(){
        System.out.println("1- Insertar nuevo registro");
        System.out.println("2- Mostrar la tabla");
        System.out.println("3- Modificar un registro");
        System.out.println("4- Eliminar un registro");
        System.out.println("5- Salir");
    }
    
    public static void ExDB(){
        System.out.println(">>> Extrayendo la base de datos, por favor espere!...");
    }
}
