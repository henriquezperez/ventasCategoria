package datos;
import domain.Proveedor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class ProveedorJDBC {
    private static final String SQL_SELECT = "SELECT * FROM proveedor";
    private static final String SQL_INSERT = "INSERT INTO proveedor (nombre, direccion, email, telefono, NIT, NRC, contacto) values (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE proveedor set nombre=?, direccion=?, email=?, telefono=?, NIT=?, NRC=?, contacto=? WHERE idProveedor=?";
    private static final String SQL_DELETE = "DELETE FROM proveedor WHERE idProveedor=?";
    
public List<Proveedor> select(){
    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet  rs = null;
    Proveedor proveedor = null;
    List<Proveedor> proveedors = new ArrayList<Proveedor>();
     try{
        conn = Conexion.getConnection();
        stmt = conn.prepareStatement(SQL_SELECT);
        rs = stmt.executeQuery();
        while(rs.next()){
            proveedor = new Proveedor();
            proveedor.setIdProveedor(rs.getInt("idProveedor"));
            proveedor.setNombre(rs.getString("nombre"));
            proveedor.setDireccion(rs.getString("direccion"));
            proveedor.setEmail(rs.getString("email"));
            proveedor.setTelefono(rs.getString("telefono"));
            proveedor.setNIT(rs.getString("NIT"));
            proveedor.setNRC(rs.getString("NRC"));
            proveedor.setContacto(rs.getString("contacto"));
            proveedors.add(proveedor);
        }
     }catch(SQLException ex){
        ex.printStackTrace(System.out);
     }finally{
        Conexion.close(rs);
        Conexion.close(stmt);
        Conexion.close(conn);    
     }
        return proveedors;
    }
    
    public int insert(Proveedor proveedor){
    Connection conn = null;
    PreparedStatement stmt = null;
   int row=0;
     try{
        conn = Conexion.getConnection();
        stmt = conn.prepareStatement(SQL_INSERT);
        stmt.setString(1, proveedor.getNombre());
        stmt.setString(2, proveedor.getDireccion());
        stmt.setString(3, proveedor.getEmail());
        stmt.setString(4, proveedor.getTelefono());
        stmt.setString(5, proveedor.getNIT());
        stmt.setString(6, proveedor.getNRC());
        stmt.setString(7, proveedor.getContacto());
        row = stmt.executeUpdate();
        System.out.println("\nDatos insertados correctamente!...");
     }catch(SQLException ex){
        ex.printStackTrace(System.out);
     }finally{
        Conexion.close(stmt);
        Conexion.close(conn);    
     }
        return row;
    }
    
    public int update(Proveedor proveedor){
    Connection conn = null;
    PreparedStatement stmt = null;
     int row=0;
     try{
        conn = Conexion.getConnection();
        stmt = conn.prepareStatement(SQL_UPDATE);
        stmt.setString(1, proveedor.getNombre());
        stmt.setString(2, proveedor.getDireccion());
        stmt.setString(3, proveedor.getEmail());
        stmt.setString(4, proveedor.getTelefono());
        stmt.setString(5, proveedor.getNIT());
        stmt.setString(6, proveedor.getNRC());
        stmt.setString(7, proveedor.getContacto());
        stmt.setInt(8, proveedor.getIdProveedor());
        
        row = stmt.executeUpdate();
        System.out.println("\nRegistros actualizados!...");
     }catch(SQLException ex){
        ex.printStackTrace(System.out);
     }finally{
        Conexion.close(stmt);
        Conexion.close(conn);    
     }
        return row;
    }
    
    public int delete(Proveedor proveedor){
    Connection conn = null;
    PreparedStatement stmt = null;
   int row=0;
     try{
        conn = Conexion.getConnection();
        stmt = conn.prepareStatement(SQL_DELETE);
        stmt.setInt(1, proveedor.getIdProveedor());
        row = stmt.executeUpdate();
        System.out.println("\nRegistros eliminado!...");
     }catch(SQLException ex){
        ex.printStackTrace(System.out);
     }finally{
        Conexion.close(stmt);
        Conexion.close(conn);    
     }
        return row;
    }
}
