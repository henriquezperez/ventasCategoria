package Test;
import datos.MarcaJDBC;
import domain.Marca;
import java.util.List;
import java.util.Scanner;

public class MarcaCRUD{
    
     public static void InsertData(){
        Line();
        String nombre;
        MarcaJDBC MarcaJDBC = new MarcaJDBC();
        System.out.println(">>> INSERTAR UN DATO <<<");
        Marca InsertMarca = new Marca();
        Scanner leer = new Scanner(System.in);
        System.out.println("Nombre:>");
        InsertMarca.setMarca(nombre = leer.nextLine());
        MarcaJDBC.insert(InsertMarca);
        Line();
    }
    
      public static void ExtraerData(){     
        MarcaJDBC MarcaJDBC = new MarcaJDBC();        
        List<Marca> categorias = MarcaJDBC.select();
        //System.out.println(">>> Extrayendo la base de datos, por favor espere!...");
        Line();
        if(categorias.size() < 1){
            System.out.println("No hay datos en la tabla Marca!..");
        }else{
            System.out.println("\t\t\t\t\tBASE DE DATOS\n");
            for(Marca categoria:categorias){
                System.out.println(categoria);
            }
        }
        Line();
    }
      
    public static void DeleteData(){
        Line();
        int id = 0, res=0;
        Scanner leer = new Scanner(System.in);
        MarcaJDBC MarcaJDBC = new MarcaJDBC();
        Marca DeleteMarca = new Marca();
        System.out.println("\tBORRAR DATOS");
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            do{
                System.out.println("Realmente desea eliminar los datos?:>");
                System.out.println("1-SI");
                System.out.println("2-No");
                res = leer.nextInt();
                if(res<1 || res>2){
                    System.out.println("Opcion no valida!...");
                }
            } while (res<1 || res>2);
            if(res==1){
                DeleteMarca.setIdMarca(id);
                MarcaJDBC.delete(DeleteMarca);
            }
            else{
                System.out.println(">>> Operacion cancelada!");
            }
        }
        Line();
    }
    
    public static void UpdateData(){
        Line();
        int id = 0;
        String nombre;
        System.out.println("\t\tModificar datos");
        MarcaJDBC MarcaJDBC = new MarcaJDBC();
        Marca UpdateMarca = new Marca();
        //System.out.println(">>> MODIFICANDO DATOS <<<");
        Scanner leer = new Scanner(System.in);
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            System.out.println("Nuevo Nombre Marca:>");
            UpdateMarca.setMarca(nombre = leer.nextLine());
            UpdateMarca.setIdMarca(id);
            MarcaJDBC.update(UpdateMarca);
        }
        Line();
    }
    
    public static int EvalueData(){
        int enc = 0, id = 0, pos=0;
        //char esc;
        Scanner leer = new Scanner(System.in);
        MarcaJDBC MarcaJDBC = new MarcaJDBC();
        
        List<Marca> marcas = MarcaJDBC.select();
        do{
            id=0;
            pos=0;
            Line();
            //System.out.println(">>> MODIFICANDO DATOS <<<");
            System.out.println("Ingrese el identificador (id), para salir -> '0':");
            System.out.println(":>");
            id = leer.nextInt();
            if(id == 0){break;}
            System.out.println("\t\t\t\t\tBuscando identificador...\n");
            for(Marca Marca:marcas){
                if(id != Marca.getIdMarca()){
                    enc  = 0;
                }
                else{
                    enc = 1;
                    break;
                }
                pos++;
            }
            if(id<0){
                System.out.println(">>> Error: No existen identificadores negativos! " + "->" + " ["+ id +"]");
            }
            else if(enc == 0){
                System.out.println("Este identificador [" + id + "] no existe en la base de datos o fue eliminado!");
            }
            else if(enc == 1){
                System.out.println("*** ID = [" + id + "] Encontrado! ***");
                System.out.println("Datos:\n" + marcas.get(pos));
            }
            Line();
        }while(enc != 1 || id == 0);
        return id;
    }
    
    public static void Line(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }
}