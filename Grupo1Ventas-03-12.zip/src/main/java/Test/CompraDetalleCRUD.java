
package Test;

public class CompraDetalleCRUD {
    
}
