/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;
import domain.Presentacion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mariana
 */
public class PresentacionJDBC {
    private static final String SQL_SELECT = "SELECT * FROM presentacion";
    private static final String SQL_INSERT = "INSERT INTO presentacion (presentacion) values (?)";
    private static final String SQL_UPDATE = "UPDATE presentacion set presentacion=?";
    private static final String SQL_DELETE = "DELETE FROM presentacion WHERE idPresentacion=?";
    
     public List<Presentacion> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        Presentacion presentacion = null;
        List <Presentacion> presentaciones = new ArrayList<Presentacion>();
        
        try{
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            
            while(rs.next()){   
                presentacion = new Presentacion();
                presentacion.setIdPresentacion(rs.getInt("idPresentacion"));
                presentacion.setPresentacion(rs.getString("presentacion"));
                
                
                presentaciones.add(presentacion);
            }
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
        }
        finally{
            Conexion.close(rs);
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        return presentaciones;
    }
     
     //Metodos
    
     public static int  insert(Presentacion presentacion){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, presentacion.getPresentacion());
            result=stmt.executeUpdate();
            System.out.println("REGISTRO AGREGADO: "+result);
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
     
     public static int update(Presentacion presentation){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
           
            stmt=conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, presentation.getPresentacion());
            stmt.setInt(2, presentation.getIdPresentacion());
            result=stmt.executeUpdate();
            System.out.println("REGISTRO ACTUALIZADO: "+result);
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
     
     public static int delete(Presentacion presentation){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
            
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, presentation.getIdPresentacion());
            result=stmt.executeUpdate();
            System.out.println("REGISTRO ELIMINADO "+ result);
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
}
