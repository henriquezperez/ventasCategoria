
package Test;

import datos.ClienteJDBC;
import domain.Cliente;
import java.util.List;
import java.util.Scanner;

 

public class ClienteCRUD {
     public static void InsertData(){
        Line();

        String nombre;
        String direccion;
        String email;
        String telefono;
        
        ClienteJDBC clienteJDBC = new ClienteJDBC();
        System.out.println(">>> INSERTAR UN DATO <<<");
        Cliente InsertCliente = new Cliente();
        Scanner leer = new Scanner(System.in);
        System.out.println("Nombre:>");
        InsertCliente.setNombre(nombre= leer.nextLine());
        System.out.println("Direccion:>");
        InsertCliente.setDireccion(direccion= leer.nextLine());
        System.out.println("email:>");
        InsertCliente.setEmail(email= leer.nextLine());
        InsertCliente.setTelefono(telefono = leer.nextLine());
        clienteJDBC.insert(InsertCliente);
        Line();
    }
    
      public static void ExtraerData(){
     
        ClienteJDBC clienteJDBC = new ClienteJDBC();
        
        List<Cliente> clientes = clienteJDBC.select();
        Line();
        System.out.println("\t\t\t\t\tBASE DE DATOS\n");
        for(Cliente cliente:clientes){
            System.out.println(cliente);
        }
        Line();
    }
      
    public static void DeleteData(){
        Line();
        int id = 0, res=0;
        Scanner leer = new Scanner(System.in);
        ClienteJDBC categoriaJDBC = new ClienteJDBC();
        Cliente DeleteCliente = new Cliente();
        System.out.println("\tBORRAR DATOS");
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            do{
                System.out.println("Realmente desea eliminar los datos?:>");
                System.out.println("1-SI");
                System.out.println("2-No");
                res = leer.nextInt();
                if(res<1 || res>2){
                    System.out.println("Opcion no valida!...");
                }
            } while (res<1 || res>2);
            if(res==1){
                DeleteCliente.setIdCliente(id);
                categoriaJDBC.delete(DeleteCliente);
            }
            else{
                System.out.println(">>> Operacion cancelada!");
            }
        }
        Line();
    }
    
    public static void UpdateData(){
        Line();
        int id = 0;
       
        String nombre;
        String direccion;
        String email;
        String telefono;
        System.out.println("\t\tModificar datos");
       
        ClienteJDBC clienteJDBC = new ClienteJDBC();
        Cliente UpdateCliente = new Cliente();
        //System.out.println(">>> MODIFICANDO DATOS <<<");
        Scanner leer = new Scanner(System.in);
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            System.out.println("Nuevo Nombre Cliente:>");
            
           
            Cliente InsertCliente = new Cliente();
            System.out.println("Nombre:>");
            InsertCliente.setNombre(nombre= leer.nextLine());
            System.out.println("Direccion:>");
            InsertCliente.setDireccion(direccion= leer.nextLine());
            System.out.println("email:>");
            InsertCliente.setEmail(email= leer.nextLine());
            InsertCliente.setTelefono(telefono = leer.nextLine());
            clienteJDBC.insert(InsertCliente);
            UpdateCliente.setIdCliente(id);
            clienteJDBC.update(UpdateCliente);
        }
        Line();
    }
    
    public static int EvalueData(){
        int enc = 0, id = 0, pos=0;
        //char esc;
        Scanner leer = new Scanner(System.in);
        ClienteJDBC categoriaJDBC = new ClienteJDBC();
        
        List<Cliente> categorias = categoriaJDBC.select();
        do{
            id=0;
            pos=0;
            Line();
            //System.out.println(">>> MODIFICANDO DATOS <<<");
            System.out.println("Ingrese el identificador (id), para salir -> '0':");
            System.out.println(":>");
            id = leer.nextInt();
            if(id == 0){break;}
            System.out.println("\t\t\t\t\tBuscando identificador...\n");
            for(Cliente categoria:categorias){
                if(id != categoria.getIdCliente()){
                    enc  = 0;
                }
                else{
                    enc = 1;
                    break;
                }
                pos++;
            }
            if(id<0){
                System.out.println(">>> Error: No existen identificadores negativos! " + "->" + " ["+ id +"]");
            }
            else if(enc == 0){
                System.out.println("Este identificador [" + id + "] no existe en la base de datos o fue eliminado!");
            }
            else if(enc == 1){
                System.out.println("*** ID = [" + id + "] Encontrado! ***");
                System.out.println("Datos:\n" + categorias.get(pos));
            }
            Line();
        }while(enc != 1 || id == 0);
        return id;
    }
    
    public static void Line(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }
}
