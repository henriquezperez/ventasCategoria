package Test;
import datos.ProductoDAO;
import domain.Producto;
import java.util.List;
import java.util.Scanner;

public class TestProducto {

    
        
        public static void Insert(){
             ProductoDAO productDAO = new ProductoDAO();
            Producto product = new Producto();
            Scanner sc = new Scanner(System.in);
            
              System.out.println("idcategoria: ");
                product.setIdCategoria(sc.nextInt());

                System.out.println("idpresentacion: ");
                product.setIdPresentacion(sc.nextInt());

                System.out.println("idmarca: ");
                product.setIdMarca(sc.nextInt());

                System.out.println("descripcion: ");
                product.setDescripcion(sc.next());

                System.out.println("precio: ");
                product.setPrecio(sc.nextDouble());

                System.out.println("costo: ");
                product.setCosto(sc.nextDouble());

                System.out.println("stock: ");
                product.setStock(sc.nextInt());
                
                productDAO.insert(product);
        }
            
        public static void Delete(){
            ProductoDAO productDAO = new ProductoDAO();
            Producto product = new Producto();
            Scanner sc = new Scanner(System.in);
            System.out.println("Id: ");
                product.setIdProducto(sc.nextInt());
                productDAO.delete(product);
        }
        
        public static void Update(){
             ProductoDAO productDAO = new ProductoDAO();
            Producto product = new Producto();
            Scanner sc = new Scanner(System.in);
            System.out.println("idproducto: ");
                product.setIdProducto(sc.nextInt());
                System.out.println("idcategoria: ");
                product.setIdCategoria(sc.nextInt());

                System.out.println("idpresentacion: ");
                product.setIdPresentacion(sc.nextInt());

                System.out.println("idmarca: ");
                product.setIdMarca(sc.nextInt());

                System.out.println("descripcion: ");
                product.setDescripcion(sc.next());

                System.out.println("precio: ");
                product.setPrecio(sc.nextDouble());

                System.out.println("costo: ");
                product.setCosto(sc.nextDouble());

                System.out.println("stock: ");
                product.setStock(sc.nextInt());
                productDAO.update(product);
        }
        
        public static void SelectAll(){
            ProductoDAO productDAO = new ProductoDAO();
            Producto product = new Producto();
            List<Producto> productos = productDAO.select();
            for(Producto producto:productos){
                System.out.println("Producto: " + producto);
            }
        }
}

