/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import domain.Compra;
import domain.CompraDetalle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Miguel
 */
public class CompraDetalleJDBC {
    
    private static final String SQL_SELECT = "SELECT * FROM compraDetalle";
    private static final String SQL_INSERT = "INSERT INTO compraDetalle(idProveedor,nComprobante,fecha,total,descuento,iva,totalPago) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE compraDetalle SET idProveedor=?,nComprobante=?,fecha=?,total=?,descuento=?,iva=?,totalPago=? WHERE idCompra = ?";
    private static final String SQL_DELETE = "DELETE FROM compraDetalle WHERE idCompra =?";
    
    
    public List<CompraDetalle> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs= null;
       
        CompraDetalle compraDetalle = null;
        
        
        List<CompraDetalle> compraDetalles = new ArrayList<CompraDetalle>();
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_SELECT);
            rs=stmt.executeQuery();
            
            while(rs.next() ){
                compraDetalle = new CompraDetalle();
                //compraDetalle.setIdProducto(idProducto);
                compraDetalle.setIdDetalleCompra(rs.getInt("idCompraDetalle"));
                compraDetalle.setIdCompra(rs.getInt("idCompra"));
                compraDetalle.setIdProducto(rs.getInt("idProducto"));
                compraDetalle.setCantidad(rs.getInt("cantidad"));
                compraDetalle.setPrecio(rs.getDouble("precio"));
                compraDetalle.setSubTotal(rs.getDouble("subTotal"));

                compraDetalle.setSubTotal(rs.getInt("totalPago"));
                compraDetalles.add(compraDetalle);
            }
            
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
            Conexion.close(rs);
        }
        
        return compraDetalles;
    }
    
     public static int insert(CompraDetalle compraDetalle){
        int row = 0;
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = Conexion.getConnection();
            stmt =  conn.prepareStatement(SQL_INSERT);
            
            stmt.setInt(1, compraDetalle.getIdCompra());
            stmt.setInt(2, compraDetalle.getIdProducto());
            stmt.setInt(3, compraDetalle.getCantidad());
            stmt.setDouble(4, compraDetalle.getPrecio());
            stmt.setDouble(5, compraDetalle.getSubTotal());
            
            row = stmt.executeUpdate();
            
            System.out.println("Registro insertado correctamente");
            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
            System.out.println("Datos no insertados!");
        }finally{
            
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return row;
    }
    
    public static int update(CompraDetalle compraDetalle){
         Connection conn = null;
        PreparedStatement stmt = null;
        int result = 0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_UPDATE);
           stmt.setInt(1, compraDetalle.getIdCompra());
            stmt.setInt(2, compraDetalle.getIdProducto());
            stmt.setInt(3, compraDetalle.getCantidad());
            stmt.setDouble(4, compraDetalle.getPrecio());
            stmt.setDouble(5, compraDetalle.getSubTotal());
            stmt.setInt(6, compraDetalle.getIdCompra());
            result = stmt.executeUpdate();
            System.out.println("Datos Actualizados correctamente");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
    
    public static int delete(CompraDetalle compraDetalle){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
           
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, compraDetalle.getIdCompra());
            result=stmt.executeUpdate();
            System.out.println("Rgistro Eliminado!");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
}
