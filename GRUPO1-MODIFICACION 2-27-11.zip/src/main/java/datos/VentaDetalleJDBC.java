/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import domain.VentaDetalle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Miguel
 */
public class VentaDetalleJDBC {
     private static final String SQL_SELECT = "SELECT * FROM ventaDetalle";
    private static final String SQL_INSERT = "INSERT INTO ventaDetalle(idProveedor,nComprobante,fecha,total,descuento,iva,totalPago) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE ventaDetalle SET idProveedor=?,nComprobante=?,fecha=?,total=?,descuento=?,iva=?,totalPago=? WHERE idCompra = ?";
    private static final String SQL_DELETE = "DELETE FROM ventaDetalle WHERE idCompra =?";
    
    
    public List<VentaDetalle> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs= null;
       
        VentaDetalle ventaDetalle = null;
        
        
        List<VentaDetalle> ventaDetalles = new ArrayList<VentaDetalle>();
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_SELECT);
            rs=stmt.executeQuery();
            
            while(rs.next() ){
                ventaDetalle = new VentaDetalle();
                //ventaDetalle.setIdProducto(idProducto);
                ventaDetalle.setIdDetalle(rs.getInt("idDetalle"));
                ventaDetalle.setIdVenta(rs.getInt("idVenta"));
                ventaDetalle.setIdProducto(rs.getInt("idProducto"));
                ventaDetalle.setCantidad(rs.getInt("cantidad"));
                ventaDetalle.setPrecio(rs.getDouble("precio"));
                ventaDetalle.setSubTotal(rs.getDouble("subTotal"));

                ventaDetalle.setSubTotal(rs.getInt("totalPago"));
                ventaDetalles.add(ventaDetalle);
            }
            
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
            Conexion.close(rs);
        }
        
        return ventaDetalles;
    }
    
     public static int insert(VentaDetalle ventaDetalle){
        int row = 0;
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = Conexion.getConnection();
            stmt =  conn.prepareStatement(SQL_INSERT);
            
            stmt.setInt(1, ventaDetalle.getIdVenta());
            stmt.setInt(2, ventaDetalle.getIdProducto());
            stmt.setInt(3, ventaDetalle.getCantidad());
            stmt.setDouble(4, ventaDetalle.getPrecio());
            stmt.setDouble(5, ventaDetalle.getSubTotal());
            
            row = stmt.executeUpdate();
            
            System.out.println("Registro insertado correctamente");
            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
            System.out.println("Datos no insertados!");
        }finally{
            
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return row;
    }
    
    public static int update(VentaDetalle ventaDetalle){
         Connection conn = null;
        PreparedStatement stmt = null;
        int result = 0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, ventaDetalle.getIdVenta());
            stmt.setInt(2, ventaDetalle.getIdProducto());
            stmt.setInt(3, ventaDetalle.getCantidad());
            stmt.setDouble(4, ventaDetalle.getPrecio());
            stmt.setDouble(5, ventaDetalle.getSubTotal());
            stmt.setInt(6, ventaDetalle.getIdDetalle());
            result = stmt.executeUpdate();
            System.out.println("Datos Actualizados correctamente");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
    
    public static int delete(VentaDetalle ventaDetalle){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
           
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, ventaDetalle.getIdDetalle());
            result=stmt.executeUpdate();
            System.out.println("Rgistro Eliminado!");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
}
