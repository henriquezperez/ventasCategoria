
package datos;

import domain.Compra;
import domain.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CompraJDBC {
    
    private static final String SQL_SELECT = "SELECT * FROM compra";
    private static final String SQL_INSERT = "INSERT INTO compra(idProveedor,nComprobante,fecha,total,descuento,iva,totalPago) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE compra SET idProveedor=?,nComprobante=?,fecha=?,total=?,descuento=?,iva=?,totalPago=? WHERE idCompra = ?";
    private static final String SQL_DELETE = "DELETE FROM compra WHERE idCompra =?";
    
    
    public List<Compra> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs= null;
       
        Compra compra = null;
        
        
        List<Compra> compras = new ArrayList<Compra>();
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_SELECT);
            rs=stmt.executeQuery();
            
            while(rs.next() ){
                compra = new Compra();
                //compra.setIdProducto(idProducto);
                compra.setIdCompra(rs.getInt("idCompra"));
                compra.setIdProveedor(rs.getInt("idProveedor"));
                compra.setnComprobante(rs.getString("nComprobante"));
                compra.setFecha(rs.getString("fecha"));
                compra.setTotal(rs.getDouble("total"));
                compra.setDescuento(rs.getDouble("descuento"));
                compra.setIva(rs.getDouble("iva"));
                compra.setTotalPago(rs.getInt("totalPago"));
                compras.add(compra);
            }
            
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
            Conexion.close(rs);
        }
        
        return compras;
    }
    
     public static int insert(Compra compra){
        int row = 0;
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = Conexion.getConnection();
            stmt =  conn.prepareStatement(SQL_INSERT);
            
            stmt.setInt(1, compra.getIdProveedor());
            stmt.setString(2, compra.getnComprobante());
            stmt.setString(3, compra.getFecha());
            stmt.setDouble(4, compra.getTotal());
            stmt.setDouble(5, compra.getDescuento());
            stmt.setDouble(6, compra.getIva());
            stmt.setDouble(7, compra.getTotalPago());
            
            row = stmt.executeUpdate();
            
            System.out.println("Registro insertado correctamente");
            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
            System.out.println("Datos no insertados!");
        }finally{
            
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return row;
    }
    
    public static int update(Compra compra){
         Connection conn = null;
        PreparedStatement stmt = null;
        int result = 0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_UPDATE);
           stmt.setString(2, compra.getnComprobante());
            stmt.setString(3, compra.getFecha());
            stmt.setDouble(4, compra.getTotal());
            stmt.setDouble(5, compra.getDescuento());
            stmt.setDouble(6, compra.getIva());
            stmt.setDouble(7, compra.getTotalPago());
            stmt.setInt(8, compra.getIdCompra());
            result = stmt.executeUpdate();
            System.out.println("Datos Actualizados correctamente");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
    
    public static int delete(Compra compra){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
           
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, compra.getIdCompra());
            result=stmt.executeUpdate();
            System.out.println("Rgistro Eliminado!");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
    
}
