/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import domain.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Miguel
 */
public class VentaJDBC {
    
    private static final String SQL_SELECT = "SELECT * FROM venta";
    private static final String SQL_INSERT = "INSERT INTO venta(idCliente,fecha,total,descuento,iva,totalPago,nFactura) VALUES (?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE venta SET idCliente=?,fecha=?,total=?,descuento=?,iva=?,totalPago=?,nFactura=? WHERE idVenta = ?";
    private static final String SQL_DELETE = "DELETE FROM venta WHERE idVenta =?";
    
    
    public List<Venta> select(){
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs= null;
       
        Venta venta = null;
        
        
        List<Venta> ventas = new ArrayList<Venta>();
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_SELECT);
            rs=stmt.executeQuery();
            
            while(rs.next() ){
                venta = new Venta();
                //venta.setIdProducto(idProducto);
                venta.setIdVenta(rs.getInt("idVenta"));
                venta.setIdCliente(rs.getInt("idCliente"));
                venta.setFecha(rs.getString("fecha"));
                venta.setTotal(rs.getDouble("total"));
                venta.setDescuento(rs.getDouble("descuento"));
                venta.setIva(rs.getDouble("iva"));
                venta.setTotalPago(rs.getInt("totalPago"));
                venta.setnFactura(rs.getInt("nFactura"));
                ventas.add(venta);
            }
            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
            Conexion.close(rs);
        }
        
        return ventas;
    }
    
     public static int insert(Venta venta){
        int row = 0;
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = Conexion.getConnection();
            stmt =  conn.prepareStatement(SQL_INSERT);
            
            stmt.setInt(1, venta.getIdCliente());
            stmt.setString(2, venta.getFecha());
            stmt.setDouble(3, venta.getTotal());
            stmt.setDouble(4, venta.getDescuento());
            stmt.setDouble(5, venta.getIva());
            stmt.setDouble(6, venta.getTotalPago());
            stmt.setDouble(7, venta.getnFactura());
            
            row = stmt.executeUpdate();
            
            System.out.println("Registro insertado correctamente");
            
        }catch(SQLException ex){
            ex.printStackTrace(System.out);
            System.out.println("Datos no insertados!");
        }finally{
            
            Conexion.close(stmt);
            Conexion.close(conn);
        }
        
        return row;
    }
    
    public static int update(Venta venta){
         Connection conn = null;
        PreparedStatement stmt = null;
        int result = 0;
        try {
            conn=Conexion.getConnection();
            stmt=conn.prepareStatement(SQL_UPDATE);
          stmt.setInt(1, venta.getIdCliente());
            stmt.setString(2, venta.getFecha());
            stmt.setDouble(3, venta.getTotal());
            stmt.setDouble(4, venta.getDescuento());
            stmt.setDouble(5, venta.getIva());
            stmt.setDouble(6, venta.getTotalPago());
            stmt.setDouble(7, venta.getnFactura());
            stmt.setInt(8, venta.getIdVenta());
            result = stmt.executeUpdate();
            System.out.println("Datos Actualizados correctamente");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        
        return result;
    }
    
    public static int delete(Venta venta){
        Connection conn = null;
        PreparedStatement stmt = null;
        int result=0;
        try {
            conn=Conexion.getConnection();
           
            stmt=conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, venta.getIdVenta());
            result=stmt.executeUpdate();
            System.out.println("Rgistro Eliminado!");
        }catch( SQLException ex){
            ex.printStackTrace(System.out);
        }finally{
            Conexion.close(conn);
            Conexion.close(stmt);
        }
        return result;
    }
}
