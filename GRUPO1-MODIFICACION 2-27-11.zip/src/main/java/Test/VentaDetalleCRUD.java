
package Test;


public class VentaDetalleCRUD {
    
}
