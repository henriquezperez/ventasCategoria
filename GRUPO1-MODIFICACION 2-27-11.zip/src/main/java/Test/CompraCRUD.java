
package Test;


import datos.CompraJDBC;

import domain.Compra;
import java.util.List;
import java.util.Scanner;


public class CompraCRUD {
    public static void InsertData(){
        Line();

      int idProveedor;
     String nComprobante;
     String fecha;
     double total;
     double descuento;
     double iva;
     double totalPago;
        
        CompraJDBC compraJDBC = new CompraJDBC();
        Compra Update = new Compra();
        System.out.println(">>> INSERTAR UN DATO <<<");
     
        Scanner leer = new Scanner(System.in);
        System.out.println("idProveedor:>");
        Update.setIdProveedor(idProveedor= leer.nextInt());
        System.out.println("nComprobante:>");
        Update.setnComprobante(nComprobante= leer.next());
        System.out.println("Fecha:>");
        Update.setFecha(fecha= leer.next());
        System.out.println("Total:>");
        Update.setTotal(total = leer.nextDouble());
         System.out.println("Descuento:>");
        Update.setDescuento(descuento = leer.nextDouble());
         System.out.println("IVA:>");
        Update.setIva(iva = leer.nextDouble());
          System.out.println("Total pago:>");
        Update.setTotalPago(totalPago = leer.nextDouble());
        compraJDBC.insert(Update);
        Line();
    }
    
      public static void ExtraerData(){
     
        CompraJDBC compraJDBC = new CompraJDBC();
        
        List<Compra> compras = compraJDBC.select();
        
        Line();
        System.out.println("\t\t\t\t\tBASE DE DATOS\n");
        for(Compra compra:compras){
            System.out.println(compra);
        }
        Line();
    }
      
    public static void DeleteData(){
        Line();
        int id = 0, res=0;
        Scanner leer = new Scanner(System.in);
        CompraJDBC com = new CompraJDBC();
        Compra Delete = new Compra();
        System.out.println("\tBORRAR DATOS");
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            do{
                System.out.println("Realmente desea eliminar los datos?:>");
                System.out.println("1-SI");
                System.out.println("2-No");
                res = leer.nextInt();
                if(res<1 || res>2){
                    System.out.println("Opcion no valida!...");
                }
            } while (res<1 || res>2);
            if(res==1){
                Delete.setIdCompra(id);
                com.delete(Delete);
            }
            else{
                System.out.println(">>> Operacion cancelada!");
            }
        }
        Line();
    }
    
    public static void UpdateData(){
        Line();
        int id = 0;
       
              Line();

        int idProveedor;
       String nComprobante;
       String fecha;
       double total;
       double descuento;
       double iva;
       double totalPago;
        
        System.out.println("\t\tModificar datos");
        CompraJDBC compra = new CompraJDBC();
        Compra Update = new Compra();
        //System.out.println(">>> MODIFICANDO DATOS <<<");
        Scanner leer = new Scanner(System.in);
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            System.out.println("Nuevo Nombre Cliente:>");
            
           
           Compra com = new Compra();
           System.out.println("idProveedor:>");
            Update.setIdProveedor(idProveedor= leer.nextInt());
            System.out.println("nComprobante:>");
            Update.setnComprobante(nComprobante= leer.next());
            System.out.println("Fecha:>");
            Update.setFecha(fecha= leer.next());
            System.out.println("Total:>");
            Update.setTotal(total = leer.nextDouble());
             System.out.println("Descuento:>");
            Update.setDescuento(descuento = leer.nextDouble());
             System.out.println("IVA:>");
            Update.setIva(iva = leer.nextDouble());
              System.out.println("Total pago:>");
            Update.setTotalPago(totalPago = leer.nextDouble());
            
            Update.setIdCompra(id);
            compra.update(Update);
        }
        Line();
    }
    
    public static int EvalueData(){
        int enc = 0, id = 0, pos=0;
        //char esc;
        Scanner leer = new Scanner(System.in);
        CompraJDBC compraJDBC = new CompraJDBC();
        
        List<Compra> compras = compraJDBC.select();
        
        do{
            id=0;
            pos=0;
            Line();
            //System.out.println(">>> MODIFICANDO DATOS <<<");
            System.out.println("Ingrese el identificador (id), para salir -> '0':");
            System.out.println(":>");
            id = leer.nextInt();
            if(id == 0){break;}
            System.out.println("\t\t\t\t\tBuscando identificador...\n");
            for(Compra compra:compras){
                if(id != compra.getIdCompra()){
                    enc  = 0;
                }
                else{
                    enc = 1;
                    break;
                }
                pos++;
            }
            if(id<0){
                System.out.println(">>> Error: No existen identificadores negativos! " + "->" + " ["+ id +"]");
            }
            else if(enc == 0){
                System.out.println("Este identificador [" + id + "] no existe en la base de datos o fue eliminado!");
            }
            else if(enc == 1){
                System.out.println("*** ID = [" + id + "] Encontrado! ***");
                System.out.println("Datos:\n" + compras.get(pos));
            }
            Line();
        }while(enc != 1 || id == 0);
        return id;
    }
    
    public static void Line(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }
}
