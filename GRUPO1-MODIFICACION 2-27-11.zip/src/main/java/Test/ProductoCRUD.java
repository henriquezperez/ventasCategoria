package Test;

import datos.ProductoJDBC;
import domain.Producto;
import java.util.List;
import java.util.Scanner;

public class ProductoCRUD {

   public static void InsertData(){
        Line();

        int idCategoria; 
        int idPresentacion;
        int idMarca;
        String descripcion; 
        double precio;
        double costo;
        int stock;
        
        ProductoJDBC productoJDBC = new ProductoJDBC();
        
        System.out.println(">>> INSERTAR UN DATO <<<");
        Producto InsertProducto = new Producto();
        
        Scanner leer = new Scanner(System.in);
       
        System.out.println("id Categoria:>");
        InsertProducto.setIdCategoria(idCategoria = leer.nextInt());
        System.out.println("id Presentacion:>");
        InsertProducto.setIdProducto(idPresentacion = leer.nextInt());
        System.out.println("id Marca:>");
        InsertProducto.setIdMarca(idMarca = leer.nextInt());
         System.out.println("Descripcion:>");
        InsertProducto.setDescripcion(descripcion = leer.next());
        System.out.println("Precio:>");
        InsertProducto.setPrecio(precio = leer.nextDouble());
        System.out.println("Costo:>");
        InsertProducto.setCosto(costo = leer.nextDouble());
        System.out.println("Stock:>");
        InsertProducto.setStock(stock = leer.nextInt());
    
        productoJDBC.insert(InsertProducto);
        
        Line();
    }

    public static void ExtraerData(){

      ProductoJDBC productoJDBC = new ProductoJDBC();

      List<Producto> productos = productoJDBC.select();
      
      Line();
      System.out.println("\t\t\t\t\tBASE DE DATOS\n");
      for(Producto producto:productos){
          System.out.println(producto);
      }
      Line();
    }

    public static void DeleteData(){
        Line();
        int id = 0, res=0;
        Scanner leer = new Scanner(System.in);
        ProductoJDBC productoJDBC = new ProductoJDBC();
        Producto DeleteProducto = new Producto();
        System.out.println("\tBORRAR DATOS");
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            do{
                System.out.println("Realmente desea eliminar los datos?:>");
                System.out.println("1-SI");
                System.out.println("2-No");
                res = leer.nextInt();
                if(res<1 || res>2){
                    System.out.println("Opcion no valida!...");
                }
            } while (res<1 || res>2);
            if(res==1){
                DeleteProducto.setIdProducto(id);
                productoJDBC.delete(DeleteProducto);
            }
            else{
                System.out.println(">>> Operacion cancelada!");
            }
        }
        Line();
    }

    public static void UpdateData(){
        Line();
        int id = 0;
        
        int idCategoria; 
        int idPresentacion;
        int idMarca;
        String descripcion; 
        double precio;
        double costo;
        int stock;
        
        Scanner leer = new Scanner(System.in);
        System.out.println("\t\tModificar datos");
        ProductoJDBC productoJDBC = new ProductoJDBC();
        Producto InsertProducto = new Producto();
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            System.out.println("Introduzca los nuevos datos:\n");
            System.out.println("id Categoria:>");
            InsertProducto.setIdCategoria(idCategoria = leer.nextInt());
            System.out.println("id Presentacion:>");
            InsertProducto.setIdProducto(idPresentacion = leer.nextInt());
            System.out.println("id Marca:>");
            InsertProducto.setIdMarca(idMarca = leer.nextInt());
            System.out.println("Descripcion:>");
            InsertProducto.setDescripcion(descripcion = leer.next());
            System.out.println("Precio:>");
            InsertProducto.setPrecio(precio = leer.nextDouble());
            System.out.println("Costo:>");
            InsertProducto.setCosto(costo = leer.nextDouble());
            System.out.println("Stock:>");
            InsertProducto.setStock(stock = leer.nextInt());
            
            InsertProducto.setIdProducto(id);
            productoJDBC.update(InsertProducto);
        }
        Line();
    }

       public static int EvalueData(){
        int enc = 0, id = 0, pos=0;
        Scanner leer = new Scanner(System.in);
        ProductoJDBC productoJDBC = new ProductoJDBC();
        List<Producto> productos = productoJDBC.select();
        do{
            id=0;
            pos=0;
            Line();
            System.out.println("Ingrese el identificador (id), para salir -> '0':");
            System.out.println(":>");
            id = leer.nextInt();
            if(id == 0){break;}
            System.out.println("\t\t\t\t\tBuscando identificador...\n");
            for(Producto producto:productos){
                if(id != producto.getIdProducto()){
                    enc  = 0;
                }
                else{
                    enc = 1;
                    break;
                }
                pos++;
            }
            if(id<0){
                System.out.println(">>> Error: No existen identificadores negativos! " + "->" + " ["+ id +"]");
            }
            else if(enc == 0){
                System.out.println("Este identificador [" + id + "] no existe en la base de datos o fue eliminado!");
            }
            else if(enc == 1){
                System.out.println("*** ID = [" + id + "] Encontrado! ***");
                System.out.println("Datos:\n" + productos.get(pos));
            }
            Line();
        }while(enc != 1 || id == 0);
        return id;
    }

    public static void Line(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }
}