
package Test;
import datos.ProveedorJDBC;
import domain.Proveedor;
import java.util.List;
import java.util.Scanner;

public class ProveedorCRUD {
    
    
    public static void ExtraerData(){
        
            ProveedorJDBC proveedorJDBC = new ProveedorJDBC();
        
        List<Proveedor> proveedores = proveedorJDBC.select();
        
        Line();
        System.out.println("\t\t\t\t\tBASE DE DATOS\n");
        for(Proveedor proveedor:proveedores){
            System.out.println(proveedor);
        }
        Line();
    }
    
   public static void InsertData(){
           Line();
     String nombre;
     String direccion;
     String email;
     String telefono;
     String NIT;
     String NRC;
     String contacto;
        
        ProveedorJDBC proveedorJDBC = new ProveedorJDBC();
        Proveedor UpdateProveedor = new Proveedor();
        
        System.out.println(">>> INSERTAR UN DATO <<<");
        Scanner leer = new Scanner(System.in);
        
        System.out.println("Nombre:>");
        UpdateProveedor.setNombre(nombre = leer.next());
        System.out.println("Direccion:>");
        UpdateProveedor.setDireccion(direccion = leer.next());
        System.out.println("email:>");
        UpdateProveedor.setEmail(email = leer.next());
        System.out.println("Telefono:>");
        UpdateProveedor.setTelefono(telefono = leer.next());
        System.out.println("NIT:>");
        UpdateProveedor.setNIT(NIT = leer.next());
        System.out.println("NRC:>");
        UpdateProveedor.setNRC(NRC = leer.next());
        System.out.println("contacto:>");
        UpdateProveedor.setContacto(contacto = leer.next());
        
        proveedorJDBC.insert(UpdateProveedor);
        Line();
    }
   
   
    public static void UpdateData(){
        ProveedorJDBC proveedorJDBC = new ProveedorJDBC();
        Proveedor UpdateProveedor = new Proveedor();
         Line();
        int id = 0;
     String nombre;
     String direccion;
     String email;
     String telefono;
     String NIT;
     String NRC;
     String contacto;
     
        System.out.println("\t\tModificar datos");
      
        Scanner leer = new Scanner(System.in);
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            System.out.println("Nuevos DATOS:>");
            
            System.out.println("Nombre:>");
           UpdateProveedor.setNombre(nombre = leer.next());
           System.out.println("Direccion:>");
           UpdateProveedor.setDireccion(direccion = leer.next());
           System.out.println("email:>");
           UpdateProveedor.setEmail(email = leer.next());
           System.out.println("Telefono:>");
           UpdateProveedor.setTelefono(telefono = leer.next());
           System.out.println("NIT:>");
           UpdateProveedor.setNIT(NIT = leer.next());
           System.out.println("NRC:>");
           UpdateProveedor.setNRC(NRC = leer.next());
           System.out.println("contacto:>");
           UpdateProveedor.setContacto(contacto = leer.next());
            
            UpdateProveedor.setIdProveedor(id);
            proveedorJDBC.update(UpdateProveedor);
        }
        Line();
    }
    
    public static void DeleteData(){
         Line();
        int id = 0, res=0;
        Scanner leer = new Scanner(System.in);
         ProveedorJDBC proveedorJDBC = new ProveedorJDBC();
         
        Proveedor Delete = new Proveedor();
        System.out.println("\tBORRAR DATOS");
        id = EvalueData();
        if(id == 0){
            System.out.println(">>> Salio de la opcion!");
        }
        else{
            do{
                System.out.println("Realmente desea eliminar los datos?:>");
                System.out.println("1-SI");
                System.out.println("2-No");
                res = leer.nextInt();
                if(res<1 || res>2){
                    System.out.println("Opcion no valida!...");
                }
            } while (res<1 || res>2);
            if(res==1){
                Delete.setIdProveedor(id);
                proveedorJDBC.delete(Delete);
            }
            else{
                System.out.println(">>> Operacion cancelada!");
            }
        }
        Line();
    }
    
     public static int EvalueData(){
        int enc = 0, id = 0, pos=0;
        //char esc;
        Scanner leer = new Scanner(System.in);
       ProveedorJDBC proveedorJDBC = new ProveedorJDBC();
        
        List<Proveedor> proveedores = proveedorJDBC.select();
        
        do{
            id=0;
            pos=0;
            Line();
            //System.out.println(">>> MODIFICANDO DATOS <<<");
            System.out.println("Ingrese el identificador (id), para salir -> '0':");
            System.out.println(":>");
            id = leer.nextInt();
            if(id == 0){break;}
            System.out.println("\t\t\t\t\tBuscando identificador...\n");
            for(Proveedor proveedor:proveedores){
                if(id != proveedor.getIdProveedor()){
                    enc  = 0;
                }
                else{
                    enc = 1;
                    break;
                }
                pos++;
            }
            if(id<0){
                System.out.println(">>> Error: No existen identificadores negativos! " + "->" + " ["+ id +"]");
            }
            else if(enc == 0){
                System.out.println("Este identificador [" + id + "] no existe en la base de datos o fue eliminado!");
            }
            else if(enc == 1){
                System.out.println("*** ID = [" + id + "] Encontrado! ***");
                System.out.println("Datos:\n" + proveedores.get(pos));
            }
            Line();
        }while(enc != 1 || id == 0);
        return id;
    }
    
   
     public static void Line(){
        System.out.println("\n------------------------------------------------------------------------------------------------------------");
    }
}
