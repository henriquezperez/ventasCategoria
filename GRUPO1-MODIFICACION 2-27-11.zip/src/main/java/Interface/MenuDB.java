
package Interface;
// https://github.com/miguelhenriquez503

import java.util.Scanner;

public class MenuDB {
    
    public static void main(String[] args) {
        Infor();
        int op = 0;
        do{
           Menu();
            do{
                System.out.println("Opcion:>");
                Scanner leer = new Scanner(System.in);
                op  = leer.nextInt();
                if(op<1 || op >7){
                    System.out.println("Opcion [" + op + "] no es valida!");
                }
            }while(op<1 || op >7);
            switch(op){
                case 1:
                     MenuTabla.CategoriaTB();
                     break;
                case 2:
                    MenuTabla.ClienteTB();
                     break;
                case 3:
                   MenuTabla.MarcaTB();
                     break;
                case 4:
                    MenuTabla.PresentacioTB();
                     break;
                case 5:
                    MenuTabla.ProductoTB();
                     break;
                case 6:
                    MenuTabla.ProveedorTB();
                     break;
            }
        }while(op != 7);
        System.out.println(">>> PROGRAMA TERMINADO <<<");
    }
    
     public static void Infor(){
       System.out.println("\nPROGRAMACÓN APLICADA 1");
       System.out.println("\nINTEGRANTES:"); 
       System.out.println("Marlon Enrique Moran Guevara");
       System.out.println("Jairo Vladimir Osorio Portillo");
       System.out.println("Wilmer Omar Alvarez Sanchez");
       System.out.println("Welner Edgardo Catalan Rivera");
       System.out.println("Kevin Miguel Henriquez Perez\n");
    }
     
     public static void Menu(){
        System.out.println("\t*** MENU DE LA BASE DE DATOS: VENTAS ***\n");
        System.out.println("\t>>>TABLAS DE DB <<<");
        System.out.println("1- Categoria");
        System.out.println("2- Cliente");
        System.out.println("3- Marca");
        System.out.println("4- Presentacion");
        System.out.println("5- Producto");
        System.out.println("6- Proveedor");
        System.out.println("7- Salir");
     }
}